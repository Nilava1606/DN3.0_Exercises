public class StripeGateway {
    public void sendPayment(double amount) {
        System.out.println("Payment of $" + amount + " made through Stripe.");
    }
}