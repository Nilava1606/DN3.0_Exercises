// Main.java
public class Main {
    public static void main(String[] args) {
        PaymentContext paymentContext = new PaymentContext();

        PaymentStrategy creditCardPayment = new CreditCardPayment("2233-5566-1177-7799", "Nilava Bishnu"); //Random Card Number
        paymentContext.setPaymentStrategy(creditCardPayment);
        paymentContext.pay(455.75);

        PaymentStrategy payPalPayment = new PayPalPayment("nilavabishnu@gmail.com");
        paymentContext.setPaymentStrategy(payPalPayment);
        paymentContext.pay(250.00);
    }
}

